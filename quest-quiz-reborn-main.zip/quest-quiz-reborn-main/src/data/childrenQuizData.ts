
import { QuizData } from './quizData';

const childrenQuizData: QuizData = {
  title: "Zlatá dobrodružná výprava",
  intro: "Ahoj malý průzkumníku!",
  description: "Vydej se s námi na cestu za pokladem! Odpověz na zábavné otázky o zlatých dolech v Jílovém u Prahy. Jsi připraven na dobrodružství?",
  questions: [
    {
      id: 1,
      text: "Jakou barvu má zlato?",
      answers: [
        { id: 1, text: "Žlutou", isCorrect: true },
        { id: 2, text: "Zelenou", isCorrect: false },
        { id: 3, text: "Modrou", isCorrect: false },
        { id: 4, text: "Červenou", isCorrect: false }
      ]
    },
    {
      id: 2,
      text: "Co se dříve používalo k hledání zlata v řece?",
      answers: [
        { id: 1, text: "Lžíce", isCorrect: false },
        { id: 2, text: "Rýžovací pánev", isCorrect: true },
        { id: 3, text: "Vidlička", isCorrect: false },
        { id: 4, text: "Kyblík", isCorrect: false }
      ]
    },
    {
      id: 3,
      text: "Jak se jmenuje muzeum v Jílovém u Prahy?",
      answers: [
        { id: 1, text: "Muzeum zlata", isCorrect: true },
        { id: 2, text: "Muzeum dinosaurů", isCorrect: false },
        { id: 3, text: "Muzeum vody", isCorrect: false },
        { id: 4, text: "Muzeum planet", isCorrect: false }
      ]
    },
    {
      id: 4,
      text: "Jak se jmenuje jeden z nejznámějších dolů u Jílového?",
      answers: [
        { id: 1, text: "Důl sv. Josefa", isCorrect: true },
        { id: 2, text: "Důl krále Karla", isCorrect: false },
        { id: 3, text: "Čokoládový důl", isCorrect: false },
        { id: 4, text: "Perníkový důl", isCorrect: false }
      ]
    },
    {
      id: 5,
      text: "Kde horníci hledali zlato?",
      answers: [
        { id: 1, text: "V mracích", isCorrect: false },
        { id: 2, text: "Pod zemí v dolech", isCorrect: true },
        { id: 3, text: "Na střechách domů", isCorrect: false },
        { id: 4, text: "V obchodech", isCorrect: false }
      ]
    },
    {
      id: 6, 
      text: "Kolik zastavení má stezka Jílovské doly?",
      answers: [
        { id: 1, text: "5", isCorrect: false },
        { id: 2, text: "8", isCorrect: false },
        { id: 3, text: "12", isCorrect: true },
        { id: 4, text: "20", isCorrect: false }
      ]
    },
    {
      id: 7,
      text: "Jaké zvířátko můžeš potkat na stezce v Jílovém?",
      answers: [
        { id: 1, text: "Tučňáka", isCorrect: false },
        { id: 2, text: "Veverku", isCorrect: true },
        { id: 3, text: "Žirafu", isCorrect: false },
        { id: 4, text: "Velrybu", isCorrect: false }
      ]
    }
  ],
  completionMessage: "Hurá! Dokončil jsi zlatou výpravu! Jsi opravdový hrdina a znalec zlatých dolů!"
};

export default childrenQuizData;

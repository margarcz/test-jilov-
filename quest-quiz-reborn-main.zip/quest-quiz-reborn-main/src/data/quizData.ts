
import { Question } from "../types/quiz";

export interface Answer {
  id: number;
  text: string;
  isCorrect: boolean;
}

export interface QuizData {
  title: string;
  intro: string;
  description: string;
  questions: Question[];
  completionMessage: string;
}

const adultQuizData: QuizData = {
  title: "Zlatá stezka Jílovských dolů",
  intro: "Vítejte na zlaté stezce!",
  description: "Otestujte své znalosti o historii těžby zlata v Jílovém u Prahy a okolí. Projděte si otázky týkající se zlatonosných dolů, historie těžby a zajímavostí z naučné stezky Jílovské doly.",
  questions: [
    {
      id: 1,
      text: "Jak dlouhá je naučná stezka Jílovské doly?",
      answers: [
        { id: 1, text: "2,5 km", isCorrect: false },
        { id: 2, text: "4,5 km", isCorrect: true },
        { id: 3, text: "6 km", isCorrect: false },
        { id: 4, text: "8,5 km", isCorrect: false }
      ]
    },
    {
      id: 2,
      text: "Kolik zastavení má naučná stezka Jílovské doly?",
      answers: [
        { id: 1, text: "5 zastavení", isCorrect: false },
        { id: 2, text: "8 zastavení", isCorrect: false },
        { id: 3, text: "12 zastavení", isCorrect: true },
        { id: 4, text: "15 zastavení", isCorrect: false }
      ]
    },
    {
      id: 3,
      text: "Který důl NENÍ součástí stezky Jílovské doly?",
      answers: [
        { id: 1, text: "Důl sv. Antonína Paduánského", isCorrect: false },
        { id: 2, text: "Důl sv. Josefa", isCorrect: false },
        { id: 3, text: "Důl Pepita", isCorrect: true },
        { id: 4, text: "Rotlev", isCorrect: false }
      ]
    },
    {
      id: 4,
      text: "Který z těchto dolů byl významný díky odvodňovací štole?",
      answers: [
        { id: 1, text: "Důl sv. Antonína Paduánského", isCorrect: false },
        { id: 2, text: "Důl sv. Josefa", isCorrect: true },
        { id: 3, text: "Halíře", isCorrect: false },
        { id: 4, text: "Rotlev", isCorrect: false }
      ]
    },
    {
      id: 5,
      text: "Kdy byla největší sláva těžby zlata v Jílovém?",
      answers: [
        { id: 1, text: "Ve 12. století", isCorrect: false },
        { id: 2, text: "Ve 14. století", isCorrect: true },
        { id: 3, text: "V 16. století", isCorrect: false },
        { id: 4, text: "V 19. století", isCorrect: false }
      ]
    },
    {
      id: 6,
      text: "Co je to tzv. zlatonosná žíla?",
      answers: [
        { id: 1, text: "Podzemní řeka se zlatými nánosy", isCorrect: false },
        { id: 2, text: "Puklina v hornině vyplněná křemenem se zlatem", isCorrect: true },
        { id: 3, text: "Speciální důlní chodba", isCorrect: false },
        { id: 4, text: "Historická cesta obchodníků se zlatem", isCorrect: false }
      ]
    },
    {
      id: 7,
      text: "Které barvy jsou typické pro horniny v lokalitě?",
      answers: [
        { id: 1, text: "Bílá a modrá", isCorrect: false },
        { id: 2, text: "Zelená a šedivá", isCorrect: true },
        { id: 3, text: "Černá a červená", isCorrect: false },
        { id: 4, text: "Žlutá a hnědá", isCorrect: false }
      ]
    }
  ],
  completionMessage: "Gratulujeme k dokončení kvízu o zlatých dolech Jílovska! Nyní lépe znáte bohatou historii těžby zlata v této oblasti."
};

export default adultQuizData;

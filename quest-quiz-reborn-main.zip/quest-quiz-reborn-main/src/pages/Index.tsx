
import React from 'react';
import Quiz from '../components/Quiz';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Quiz />
    </div>
  );
};

export default Index;

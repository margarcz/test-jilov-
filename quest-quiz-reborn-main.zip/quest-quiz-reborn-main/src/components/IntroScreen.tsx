
import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { ArrowRight } from 'lucide-react';

const IntroScreen: React.FC = () => {
  const { quizData, startQuiz } = useQuiz();

  return (
    <div className="quiz-card">
      <h1 className="quiz-title animate-bounce-in">{quizData.title}</h1>
      <h2 className="quiz-subtitle">{quizData.intro}</h2>
      <p className="quiz-text">{quizData.description}</p>
      <button 
        className="primary-button group"
        onClick={startQuiz}
      >
        Začít dobrodružství
        <ArrowRight className="inline ml-2 group-hover:translate-x-1 transition-transform" size={20} />
      </button>
    </div>
  );
};

export default IntroScreen;

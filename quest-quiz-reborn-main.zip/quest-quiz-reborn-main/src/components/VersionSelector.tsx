
import React from 'react';
import { Button } from '@/components/ui/button';
import { User, UserRound } from 'lucide-react';

interface VersionSelectorProps {
  onSelectVersion: (version: 'adult' | 'children') => void;
}

const VersionSelector: React.FC<VersionSelectorProps> = ({ onSelectVersion }) => {
  return (
    <div className="quiz-card flex flex-col items-center">
      <h1 className="quiz-title mb-8">Zlaté dobrodružství</h1>
      <h2 className="quiz-subtitle mb-6">Vyberte verzi:</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-md">
        <Button 
          className="version-button flex flex-col items-center p-6 h-auto group"
          onClick={() => onSelectVersion('adult')}
        >
          <UserRound size={48} className="mb-4 group-hover:text-quiz-gold transition-colors" />
          <span className="text-lg font-medium">Pro dospělé</span>
        </Button>
        
        <Button 
          className="version-button-children flex flex-col items-center p-6 h-auto group bg-amber-100 text-amber-950 hover:bg-amber-200"
          onClick={() => onSelectVersion('children')}
        >
          <User size={48} className="mb-4 group-hover:text-amber-500 transition-colors" />
          <span className="text-lg font-medium">Pro děti</span>
        </Button>
      </div>
    </div>
  );
};

export default VersionSelector;

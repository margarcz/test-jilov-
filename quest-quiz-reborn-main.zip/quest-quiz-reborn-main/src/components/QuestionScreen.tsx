
import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { motion } from 'framer-motion';
import { ChevronRight, CheckCircle, XCircle } from 'lucide-react';

const QuestionScreen: React.FC = () => {
  const { 
    currentQuestion, 
    totalQuestions, 
    state, 
    progress,
    selectAnswer, 
    goToNextQuestion 
  } = useQuiz();

  if (!currentQuestion) return null;

  const getButtonClass = (answerId: number) => {
    if (!state.isAnswerSelected) return "answer-button";
    
    const answer = currentQuestion.answers.find(a => a.id === answerId);
    
    if (answer?.isCorrect) {
      return "answer-button-correct";
    }
    
    if (state.selectedAnswer?.id === answerId && !answer?.isCorrect) {
      return "answer-button-incorrect";
    }
    
    return "answer-button opacity-50";
  };

  return (
    <div className="quiz-card">
      <div className="progress-bar">
        <div 
          className="progress-fill" 
          style={{ width: `${progress}%` }} 
        />
      </div>
      
      <div className="flex justify-between items-center mb-4">
        <span className="text-white/70">
          Otázka {state.currentQuestionIndex + 1}/{totalQuestions}
        </span>
        
        {state.isAnswerSelected && (
          <span className={`flex items-center ${state.isAnswerCorrect ? 'text-quiz-correct' : 'text-quiz-incorrect'}`}>
            {state.isAnswerCorrect 
              ? <CheckCircle className="mr-1" size={16} /> 
              : <XCircle className="mr-1" size={16} />
            }
            {state.isAnswerCorrect ? 'Správně' : 'Nesprávně'}
          </span>
        )}
      </div>
      
      <h2 className="quiz-subtitle">{currentQuestion.text}</h2>
      
      <div className="space-y-3 mb-6">
        {currentQuestion.answers.map((answer) => (
          <button
            key={answer.id}
            className={getButtonClass(answer.id)}
            onClick={() => selectAnswer(answer)}
            disabled={state.isAnswerSelected}
          >
            {answer.text}
          </button>
        ))}
      </div>
      
      {state.isAnswerSelected && (
        <button 
          className="primary-button group"
          onClick={goToNextQuestion}
        >
          Další otázka
          <ChevronRight className="inline ml-2 group-hover:translate-x-1 transition-transform" size={20} />
        </button>
      )}
    </div>
  );
};

export default QuestionScreen;

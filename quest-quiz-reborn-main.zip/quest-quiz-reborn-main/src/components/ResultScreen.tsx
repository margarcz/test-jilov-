
import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { Trophy, RotateCcw } from 'lucide-react';

const ResultScreen: React.FC = () => {
  const { quizData, totalQuestions, correctAnswersCount, resetQuiz } = useQuiz();
  
  const percentage = Math.round((correctAnswersCount / totalQuestions) * 100);
  
  const getResultMessage = () => {
    if (percentage >= 80) {
      return "Vynikající výsledek! Jste opravdový znalec!";
    } else if (percentage >= 60) {
      return "Dobrá práce! Jste na dobré cestě!";
    } else if (percentage >= 40) {
      return "Slušný pokus! Příště to bude lepší!";
    } else {
      return "Zkuste to znovu! Každá výprava začíná prvním krokem!";
    }
  };

  return (
    <div className="quiz-card">
      <div className="flex flex-col items-center mb-6">
        <Trophy className="text-quiz-gold w-16 h-16 mb-4 animate-pulse-light" />
        <h1 className="quiz-title">Dobrodružství dokončeno!</h1>
      </div>
      
      <div className="text-center mb-8">
        <div className="text-white/90 text-xl mb-2">Váš výsledek:</div>
        <div className="text-3xl font-bold text-quiz-gold">
          {correctAnswersCount} / {totalQuestions} ({percentage}%)
        </div>
        <p className="mt-4 text-white/80">{getResultMessage()}</p>
      </div>
      
      <p className="quiz-text">{quizData.completionMessage}</p>
      
      <button 
        className="primary-button group"
        onClick={resetQuiz}
      >
        <RotateCcw className="inline mr-2 group-hover:rotate-[-30deg] transition-transform" size={20} />
        Zkusit znovu
      </button>
    </div>
  );
};

export default ResultScreen;

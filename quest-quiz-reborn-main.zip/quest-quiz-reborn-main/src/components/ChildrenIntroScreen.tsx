
import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const ChildrenIntroScreen: React.FC = () => {
  const { quizData, startQuiz } = useQuiz();

  return (
    <motion.div 
      className="children-quiz-card"
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.h1 
        className="children-quiz-title"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
      >
        {quizData.title}
      </motion.h1>
      
      <motion.div
        className="children-character"
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <img 
          src="https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?auto=format&fit=crop&w=300&q=80" 
          alt="Dobrodružství"
          className="w-32 h-32 rounded-full border-4 border-amber-300 shadow-lg mb-6"
        />
      </motion.div>
      
      <h2 className="children-quiz-subtitle">{quizData.intro}</h2>
      <p className="children-quiz-text">{quizData.description}</p>
      
      <button 
        className="children-primary-button group"
        onClick={startQuiz}
      >
        Začít dobrodružství
        <ArrowRight className="inline ml-2 group-hover:translate-x-1 transition-transform" size={24} />
      </button>
    </motion.div>
  );
};

export default ChildrenIntroScreen;


import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { Trophy, RotateCcw } from 'lucide-react';
import { motion } from 'framer-motion';

const ChildrenResultScreen: React.FC = () => {
  const { quizData, totalQuestions, correctAnswersCount, resetQuiz } = useQuiz();
  
  const percentage = Math.round((correctAnswersCount / totalQuestions) * 100);
  
  const getResultMessage = () => {
    if (percentage >= 80) {
      return "Super! Jsi opravdový znalec přírody!";
    } else if (percentage >= 60) {
      return "Dobrá práce! Učíš se rychle!";
    } else if (percentage >= 40) {
      return "Hezký pokus! Příště to zvládneš ještě lépe!";
    } else {
      return "Zkus to znovu! Každá výprava začíná prvním krokem!";
    }
  };

  return (
    <motion.div 
      className="children-quiz-card"
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div 
        className="flex flex-col items-center mb-8"
        initial={{ y: -20 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Trophy className="text-amber-500 w-24 h-24 mb-4" />
        <h1 className="children-quiz-title">Hurá! Dokončil jsi dobrodružství!</h1>
      </motion.div>
      
      <motion.div 
        className="text-center mb-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <div className="text-amber-900 text-xl mb-2 font-bold">Tvůj výsledek:</div>
        <div className="text-4xl font-bold text-amber-600 mb-4">
          {correctAnswersCount} / {totalQuestions} ({percentage}%)
        </div>
        <p className="text-xl text-amber-900 font-medium">{getResultMessage()}</p>
      </motion.div>
      
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7 }}
      >
        <p className="children-quiz-text font-medium">{quizData.completionMessage}</p>
        
        <motion.button 
          className="children-primary-button group mt-6"
          onClick={resetQuiz}
          whileHover={{ scale: 1.05 }}
        >
          <RotateCcw className="inline mr-2 group-hover:rotate-[-30deg] transition-transform" size={24} />
          Zkusit znovu
        </motion.button>
      </motion.div>
    </motion.div>
  );
};

export default ChildrenResultScreen;


import React from 'react';
import { useQuiz } from '../context/QuizContext';
import { motion } from 'framer-motion';
import { ChevronRight, CheckCircle, XCircle } from 'lucide-react';

const ChildrenQuestionScreen: React.FC = () => {
  const { 
    currentQuestion, 
    totalQuestions, 
    state, 
    progress,
    selectAnswer, 
    goToNextQuestion 
  } = useQuiz();

  if (!currentQuestion) return null;

  const getButtonClass = (answerId: number) => {
    if (!state.isAnswerSelected) return "children-answer-button";
    
    const answer = currentQuestion.answers.find(a => a.id === answerId);
    
    if (answer?.isCorrect) {
      return "children-answer-button-correct";
    }
    
    if (state.selectedAnswer?.id === answerId && !answer?.isCorrect) {
      return "children-answer-button-incorrect";
    }
    
    return "children-answer-button opacity-50";
  };

  return (
    <motion.div 
      className="children-quiz-card"
      initial={{ x: 300, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -300, opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="children-progress-bar">
        <motion.div 
          className="children-progress-fill" 
          initial={{ width: `${progress - (100 / totalQuestions)}%` }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
      
      <div className="flex justify-between items-center mb-4">
        <span className="text-amber-900 font-bold text-lg">
          Otázka {state.currentQuestionIndex + 1}/{totalQuestions}
        </span>
        
        {state.isAnswerSelected && (
          <span className={`flex items-center text-lg ${state.isAnswerCorrect ? 'text-green-600' : 'text-red-600'} font-bold`}>
            {state.isAnswerCorrect 
              ? <CheckCircle className="mr-1" size={20} /> 
              : <XCircle className="mr-1" size={20} />
            }
            {state.isAnswerCorrect ? 'Správně!' : 'Zkus to znovu!'}
          </span>
        )}
      </div>
      
      <motion.h2 
        className="children-quiz-subtitle"
        initial={{ y: 10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
      >
        {currentQuestion.text}
      </motion.h2>
      
      <div className="space-y-4 mb-8">
        {currentQuestion.answers.map((answer, index) => (
          <motion.button
            key={answer.id}
            className={getButtonClass(answer.id)}
            onClick={() => selectAnswer(answer)}
            disabled={state.isAnswerSelected}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 + (index * 0.1) }}
          >
            {answer.text}
          </motion.button>
        ))}
      </div>
      
      {state.isAnswerSelected && (
        <motion.button 
          className="children-primary-button group"
          onClick={goToNextQuestion}
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          Další otázka
          <ChevronRight className="inline ml-2 group-hover:translate-x-1 transition-transform" size={24} />
        </motion.button>
      )}
    </motion.div>
  );
};

export default ChildrenQuestionScreen;

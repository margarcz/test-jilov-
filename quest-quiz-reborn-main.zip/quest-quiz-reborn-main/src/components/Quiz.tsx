
import React from 'react';
import { QuizProvider, useQuiz } from '../context/QuizContext';
import VersionSelector from './VersionSelector';
import IntroScreen from './IntroScreen';
import QuestionScreen from './QuestionScreen';
import ResultScreen from './ResultScreen';
import ChildrenIntroScreen from './ChildrenIntroScreen';
import ChildrenQuestionScreen from './ChildrenQuestionScreen';
import ChildrenResultScreen from './ChildrenResultScreen';

// QuizContent component - renders different screens based on the quiz state
const QuizContent: React.FC = () => {
  const { state, selectVersion } = useQuiz();
  
  // Render based on screen and version
  if (state.screen === 'version') {
    return <VersionSelector onSelectVersion={selectVersion} />;
  }
  
  // For children's version
  if (state.version === 'children') {
    switch (state.screen) {
      case 'intro':
        return <ChildrenIntroScreen />;
      case 'question':
        return <ChildrenQuestionScreen />;
      case 'result':
        return <ChildrenResultScreen />;
      default:
        return <ChildrenIntroScreen />;
    }
  }
  
  // For adult version
  switch (state.screen) {
    case 'intro':
      return <IntroScreen />;
    case 'question':
      return <QuestionScreen />;
    case 'result':
      return <ResultScreen />;
    default:
      return <IntroScreen />;
  }
};

// Main Quiz component that provides the QuizContext
const Quiz: React.FC = () => {
  return (
    <QuizProvider>
      <div className="quiz-container">
        <QuizContent />
      </div>
    </QuizProvider>
  );
};

export default Quiz;


import React, { createContext, useState, useContext, ReactNode } from 'react';
import adultQuizData from '../data/quizData';
import childrenQuizData from '../data/childrenQuizData';
import { QuizData } from '../data/quizData';
import { Question, Answer } from '../types/quiz';
import { toast } from "../hooks/use-toast";

// Define the Quiz state interface
interface QuizState {
  screen: 'version' | 'intro' | 'question' | 'result';
  currentQuestionIndex: number;
  answers: boolean[];
  selectedAnswer: Answer | null;
  isAnswerSelected: boolean;
  isAnswerCorrect: boolean | null;
  version: 'adult' | 'children' | null;
}

// Define the QuizContext interface
interface QuizContextType {
  quizData: QuizData;
  state: QuizState;
  currentQuestion: Question | undefined;
  totalQuestions: number;
  correctAnswersCount: number;
  progress: number;
  startQuiz: () => void;
  selectAnswer: (answer: Answer) => void;
  goToNextQuestion: () => void;
  resetQuiz: () => void;
  selectVersion: (version: 'adult' | 'children') => void;
}

// Create the QuizContext with a default value
const QuizContext = createContext<QuizContextType | undefined>(undefined);

// Initial state for the quiz
const initialState: QuizState = {
  screen: 'version',
  currentQuestionIndex: 0,
  answers: [],
  selectedAnswer: null,
  isAnswerSelected: false,
  isAnswerCorrect: null,
  version: null,
};

// QuizProvider component
export const QuizProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<QuizState>(initialState);

  // Get the right quiz data based on the version
  const quizData = state.version === 'children' ? childrenQuizData : adultQuizData;
  
  // Calculate the current question
  const currentQuestion = quizData.questions[state.currentQuestionIndex];
  
  // Total number of questions
  const totalQuestions = quizData.questions.length;
  
  // Count of correct answers
  const correctAnswersCount = state.answers.filter(Boolean).length;
  
  // Calculate progress percentage
  const progress = (state.currentQuestionIndex / totalQuestions) * 100;

  // Select the version
  const selectVersion = (version: 'adult' | 'children') => {
    setState({
      ...initialState,
      screen: 'intro',
      version,
    });
  };

  // Start the quiz by changing to the question screen
  const startQuiz = () => {
    setState({
      ...state,
      screen: 'question',
      currentQuestionIndex: 0,
      answers: [],
      selectedAnswer: null,
      isAnswerSelected: false,
      isAnswerCorrect: null,
    });
  };

  // Handle answer selection
  const selectAnswer = (answer: Answer) => {
    if (state.isAnswerSelected) return;
    
    const isCorrect = answer.isCorrect;
    
    setState({
      ...state,
      selectedAnswer: answer,
      isAnswerSelected: true,
      isAnswerCorrect: isCorrect,
    });
    
    // Show toast notification based on answer correctness
    if (isCorrect) {
      toast({
        title: state.version === 'children' ? "Správně!" : "Správně!",
        description: state.version === 'children' ? "Tvoje odpověď je správná!" : "Vaše odpověď je správná.",
        variant: "default",
      });
    } else {
      toast({
        title: state.version === 'children' ? "Zkus to znovu!" : "Nesprávně!",
        description: state.version === 'children' ? "Tvoje odpověď není správná." : "Vaše odpověď není správná.",
        variant: "destructive",
      });
    }
  };

  // Go to the next question or to the result screen if all questions answered
  const goToNextQuestion = () => {
    if (state.currentQuestionIndex === totalQuestions - 1) {
      // All questions answered, go to result screen
      setState({
        ...state,
        screen: 'result',
        answers: [...state.answers, state.isAnswerCorrect || false],
      });
    } else {
      // Go to next question
      setState({
        ...state,
        currentQuestionIndex: state.currentQuestionIndex + 1,
        answers: [...state.answers, state.isAnswerCorrect || false],
        selectedAnswer: null,
        isAnswerSelected: false,
        isAnswerCorrect: null,
      });
    }
  };

  // Reset the quiz to the version selection
  const resetQuiz = () => {
    setState(initialState);
  };

  // Value to be provided to consumers
  const value: QuizContextType = {
    quizData,
    state,
    currentQuestion,
    totalQuestions,
    correctAnswersCount,
    progress,
    startQuiz,
    selectAnswer,
    goToNextQuestion,
    resetQuiz,
    selectVersion,
  };

  return <QuizContext.Provider value={value}>{children}</QuizContext.Provider>;
};

// Custom hook to use the QuizContext
export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  return context;
};

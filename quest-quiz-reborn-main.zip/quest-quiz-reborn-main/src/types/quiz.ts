
export interface Question {
  id: number;
  text: string;
  answers: Array<{
    id: number;
    text: string;
    isCorrect: boolean;
  }>;
}

export interface Answer {
  id: number;
  text: string;
  isCorrect: boolean;
}
